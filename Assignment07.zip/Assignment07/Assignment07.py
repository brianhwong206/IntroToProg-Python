# Title: Python Error Handling and Pickling Assignment 7
# Dev:   Brian Wong
# Date:  August 26, 2019
# ChangeLog: (Who, When, What)
#   Brian Wong, 8/26/2016, Created code for assignment 7
#-------------------------------------------------#

import pickle, shelve # importing pickle and shelve modules

    # Error Handling with ValueError
class assignmentSeven():

    def errorHandling(): # Error Handling stored into errorHandling function
        try: 
            userInputOne = float(input("Please enter a value: \n")) # ask user for an initial value, convert the value to float and store as userInputOne
            userInputTwo = float(input("Please enter a second value: \n")) # ask user for a second value, convert the value to float and store as userInputTwo
            userInputSum = userInputOne + userInputTwo # calulates the sum value of the two user inputted values.
            print("The combined sum of your two values is",userInputSum) # prints the string and the sum value

        except ValueError:
            print("Sorry, you need to input a float value for this activity to run correctly.") # if ValueError is caught, then this is returned to the user.


    # Python Pickling
    def picklePath():
        paymentType = ["Cash", "Credit Card", "Check", "Mobile Payment", "PayPal"]
        currency = ["USD", "CAD", "EUR", "CNY", "JPY", "AUD"]
        currencyValue = [0.01, 0.05, 0.10, 0.25, 0.50, 1, 2, 5, 10, 20, 50, 100]

        objFileName = "C:\_PythonClass\Pickle.dat" # directory and name of the file stored into objFileName variable. DAT file type because information will be stored in as binary.

        f = open(objFileName,"wb+") # opening file object with Write to and Read from binary file
        pickle.dump(paymentType,f) # using pickle module dump method, it takes two arguments, the data and the location
        pickle.dump(currency,f) # using pickle module dump method, it takes two arguments, the data and the location
        pickle.dump(currencyValue,f) # using pickle module dump method, it takes two arguments, the data and the location
        f.close() # close file object


        print("Below is your Pickled Lists")
        f = open(objFileName,"rb")
        paymentType = pickle.load(f)
        currency = pickle.load(f)
        currencyValue = pickle.load(f)

        print(paymentType)
        print(currency)
        print(currencyValue)
        f.close()

    # Python Shelve
    def shelvePath():
        s = shelve.open("C:\_PythonClass\Pickle2.dat")
        s["PaymentType"] = ["Cash", "Credit Card", "Check", "Mobile Payment", "PayPal"]
        s["Currency"] = ["USD", "CAD", "EUR", "CNY", "JPY", "AUD"]
        s["CurrencyValue"] = [0.01, 0.05, 0.10, 0.25, 0.50, 1, 2, 5, 10, 20, 50, 100]

        print("Below is your Shelved Lists")
        print("Payment Types: \t", s["PaymentType"])
        print("Currency: \t", s["Currency"])
        print("CurrencyValue: \t", s["CurrencyValue"])

        s.close() # close file object

# Main operation
userSelection = input("\n Please select an option: (1-3) \n 1 - Error Handling \n 2 - Pickling Example \n 3 - Shelving Example \n") # Asks user what option they would like to select.

if (userSelection == '1'):
    print("\n*** Running Error Handling Function ***\n")
    assignmentSeven.errorHandling() # Runs errorHandling function
elif (userSelection == '2'):
    print("\n*** Running Pickling Function ***\n")
    assignmentSeven.picklePath() # Runs picklePath function
elif (userSelection == '3'):
    print("\n*** Running Shelving Function ***\n")
    assignmentSeven.shelvePath() # Runs shelePath function
else:
    print("Sorry, did not recognize that command")