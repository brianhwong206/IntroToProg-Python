#-------------------------------------------------#
# Title: Working with Dictionaries Assignment 5
# Dev:   Brian Wong
# Date:  August 11, 2019
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <Brian Wong>, 8/12/2019 Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

import pprint

objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []
dicHeader = {"Task": "Priority"}
# lstTable.append(dicHeader) # header does not work as expected, commenting out

# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"

f = open(objFileName,"r") # declares f as variable to file object when text file data when is read
strData = f.readlines() # strData vairable stores the contents of the fileobject
lengthOfStrData= len(strData) # identifies the length of the fileobject contents

for rows in strData:
    rows = rows.rstrip("\n")
    key, value = rows.split(",")
    dicRow = {key: value}
    lstTable.append(dicRow)

def showTable():
    # cycles through table to remove any additional \n new line items
    for rows in lstTable:
        for elements in rows:
            elements = elements.rstrip("\n")
    # while loop here checks to see if there are any empty {} dictionaries in the table
    while{} in lstTable:
        lstTable.remove({})
    pprint.pprint(lstTable, width=1)

def closeProgram():
    input("Press Enter Key to Exit.")

def addNewdata():
    print("\n")
    newTask = input("What's the name of the new Task? \n").strip()
    newPriority = input("What's the Priority status of the new task? \n").strip()
    newDicRow = {newTask: newPriority} #structure is key : value
    lstTable.append(newDicRow)
    print("Adding item to list.")
    print("\n")

def removeData():

  print("The original list is : " + str(lstTable))
  userRemoveTarget = input("Which Key would to remove? \n")
  for row in lstTable:
    if userRemoveTarget in row:
            print("Removing item from list.")
            del row[userRemoveTarget]

            
def saveToFile():
    objectFile = open("C:\\_PythonClass\\Todo.txt", "w")
    for rows in lstTable:
        newRow =', '.join("{!s},{!r}".format(key,val) for (key,val) in rows.items()) # from StackOverflow to assist with joining the key and value together as a string when being added to the file
        newRow = newRow.replace("'","")
        print(newRow)
        objectFile.writelines(newRow + "\n") # writes the string
    objectFile.close()
    print("File Saved \n")
    showTable()


# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        showTable()
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        addNewdata()
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        removeData()
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        saveToFile()
        continue
    elif (strChoice == '5'):
        closeProgram()
        break #and Exit the program